---
layout: page
title: about
tagline: 关于我 ~
sitetime: display
permalink: /about.html
---

## #作者

你可以通过以下方式联系作者

QQ: 1316341442

Email: <a href="mailto:lk@atlinker.cn">lk@atlinker.cn</a>

Github: [link9596](https://github.com/link9596)

## #捐助我

本主题使用免费，也是作者长期工作的结晶，如果你喜欢主题\~想支持作者，欢迎给作者捐赠~

<center>扫下方付款二维码即可向作者捐赠!</center>

![wechat](https://atlinker.cn/pay/wechat.png)

![pay](https://atlinker.cn/pay/apay.png)
